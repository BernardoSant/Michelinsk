﻿namespace AulaDoDia22._02
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnMostrar = new System.Windows.Forms.Button();
            this.txtDecimal = new System.Windows.Forms.TextBox();
            this.txttexto = new System.Windows.Forms.TextBox();
            this.txtbooleano = new System.Windows.Forms.TextBox();
            this.txtInteiro = new System.Windows.Forms.TextBox();
            this.lblTexto = new System.Windows.Forms.Label();
            this.lblDecimal = new System.Windows.Forms.Label();
            this.lblinteiro = new System.Windows.Forms.Label();
            this.lblbooleano = new System.Windows.Forms.Label();
            this.btnLimpar = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnMostrar
            // 
            this.btnMostrar.Location = new System.Drawing.Point(12, 372);
            this.btnMostrar.Name = "btnMostrar";
            this.btnMostrar.Size = new System.Drawing.Size(152, 48);
            this.btnMostrar.TabIndex = 0;
            this.btnMostrar.Text = "MOSTRAR  ";
            this.btnMostrar.UseVisualStyleBackColor = true;
            this.btnMostrar.Click += new System.EventHandler(this.btnMostrar_Click);
            // 
            // txtDecimal
            // 
            this.txtDecimal.Location = new System.Drawing.Point(113, 159);
            this.txtDecimal.Name = "txtDecimal";
            this.txtDecimal.Size = new System.Drawing.Size(100, 20);
            this.txtDecimal.TabIndex = 1;
            // 
            // txttexto
            // 
            this.txttexto.Location = new System.Drawing.Point(113, 229);
            this.txttexto.Name = "txttexto";
            this.txttexto.Size = new System.Drawing.Size(100, 20);
            this.txttexto.TabIndex = 2;
            // 
            // txtbooleano
            // 
            this.txtbooleano.Location = new System.Drawing.Point(113, 304);
            this.txtbooleano.Name = "txtbooleano";
            this.txtbooleano.Size = new System.Drawing.Size(100, 20);
            this.txtbooleano.TabIndex = 3;
            // 
            // txtInteiro
            // 
            this.txtInteiro.Location = new System.Drawing.Point(113, 86);
            this.txtInteiro.Name = "txtInteiro";
            this.txtInteiro.Size = new System.Drawing.Size(100, 20);
            this.txtInteiro.TabIndex = 4;
            // 
            // lblTexto
            // 
            this.lblTexto.AutoSize = true;
            this.lblTexto.Location = new System.Drawing.Point(110, 201);
            this.lblTexto.Name = "lblTexto";
            this.lblTexto.Size = new System.Drawing.Size(37, 13);
            this.lblTexto.TabIndex = 5;
            this.lblTexto.Text = "Texto ";
            // 
            // lblDecimal
            // 
            this.lblDecimal.AutoSize = true;
            this.lblDecimal.Location = new System.Drawing.Point(110, 130);
            this.lblDecimal.Name = "lblDecimal";
            this.lblDecimal.Size = new System.Drawing.Size(48, 13);
            this.lblDecimal.TabIndex = 6;
            this.lblDecimal.Text = "Decimal ";
            // 
            // lblinteiro
            // 
            this.lblinteiro.AutoSize = true;
            this.lblinteiro.Location = new System.Drawing.Point(110, 58);
            this.lblinteiro.Name = "lblinteiro";
            this.lblinteiro.Size = new System.Drawing.Size(39, 13);
            this.lblinteiro.TabIndex = 7;
            this.lblinteiro.Text = "Inteiro ";
            this.lblinteiro.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // lblbooleano
            // 
            this.lblbooleano.AutoSize = true;
            this.lblbooleano.Location = new System.Drawing.Point(110, 274);
            this.lblbooleano.Name = "lblbooleano";
            this.lblbooleano.Size = new System.Drawing.Size(55, 13);
            this.lblbooleano.TabIndex = 8;
            this.lblbooleano.Text = "Booleano ";
            this.lblbooleano.Click += new System.EventHandler(this.label4_Click);
            // 
            // btnLimpar
            // 
            this.btnLimpar.Location = new System.Drawing.Point(184, 372);
            this.btnLimpar.Name = "btnLimpar";
            this.btnLimpar.Size = new System.Drawing.Size(152, 48);
            this.btnLimpar.TabIndex = 9;
            this.btnLimpar.Text = "LIMPAR ";
            this.btnLimpar.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(348, 450);
            this.Controls.Add(this.btnLimpar);
            this.Controls.Add(this.lblbooleano);
            this.Controls.Add(this.lblinteiro);
            this.Controls.Add(this.lblDecimal);
            this.Controls.Add(this.lblTexto);
            this.Controls.Add(this.txtInteiro);
            this.Controls.Add(this.txtbooleano);
            this.Controls.Add(this.txttexto);
            this.Controls.Add(this.txtDecimal);
            this.Controls.Add(this.btnMostrar);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnMostrar;
        private System.Windows.Forms.TextBox txtDecimal;
        private System.Windows.Forms.TextBox txttexto;
        private System.Windows.Forms.TextBox txtbooleano;
        private System.Windows.Forms.TextBox txtInteiro;
        private System.Windows.Forms.Label lblTexto;
        private System.Windows.Forms.Label lblDecimal;
        private System.Windows.Forms.Label lblinteiro;
        private System.Windows.Forms.Label lblbooleano;
        private System.Windows.Forms.Button btnLimpar;
    }
}

