﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AppLista03
{
    public partial class Exescicio1 : Form
    {
        public Exescicio1()
        {
            InitializeComponent();
        }

        private void txtNum1_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnMedia_Click(object sender, EventArgs e)
        {
            float valorNum1 = float.Parse(txtNum1.Text);
            float valorNum2 = float.Parse(txtNum2.Text);
            float valorNum3 = float.Parse(txtNum3.Text);
            float media;

            media = (valorNum1 + valorNum2 + valorNum3) / 3;

            lblRMedia.Text = "Média igual a " + media;
        }

        private void btnPorcentagem_Click(object sender, EventArgs e)
        {
            //Entrada
            float valorNum1 = float.Parse(txtNum1.Text);
            float valorNum2 = float.Parse(txtNum2.Text);
            float valorNum3 = float.Parse(txtNum3.Text);
            float total, porcNum1, porcNum2, porcNum3;

            //Processamento
            total = valorNum1 + valorNum2 + valorNum3;
            porcNum1 = valorNum1 / total;
            porcNum2 = valorNum2 / total;
            porcNum3 = valorNum3 / total;

            //Saida
            lblRPorcentagem.Text = "Num1 é " + porcNum1 + "% - " + " Num2 é " + porcNum2 + "% - " + " Num3 " + porcNum3 + "% - ";
        }

        private void btnSoma_Click(object sender, EventArgs e)
        {
            float valorNum1 = float.Parse(txtNum1.Text);
            float valorNum3 = float.Parse(txtNum3.Text);
            float soma;

            soma = valorNum1 + valorNum3;

            lblRSoma.Text = "Soma igual a " + soma;
        }
    }
}
